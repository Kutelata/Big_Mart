package com.materialuiux.socialmediaapp.adapter.holder;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolderMessengerUser extends RecyclerView.ViewHolder {

    public ViewHolderMessengerUser(@NonNull View itemView) {
        super(itemView);
    }
}
