package com.materialuiux.socialmediaapp.adapter.holder;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolderMessengerFrind extends RecyclerView.ViewHolder {

    public ViewHolderMessengerFrind(@NonNull View itemView) {
        super(itemView);
    }
}
