package com.materialuiux.socialmediaapp.model;

public class Notification {
    String name;
    String profileImage;

    public Notification(String name, String profileImage) {
        this.name = name;
        this.profileImage = profileImage;
    }

    public String getName() {
        return name;
    }

    public String getProfileImage() {
        return profileImage;
    }
}
